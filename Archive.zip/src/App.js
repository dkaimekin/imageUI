import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { Navigate, Route, Routes, useNavigate } from "react-router";
import React, { useState, useEffect } from "react";
import { ScaleLoader } from "react-spinners";
import { Container, Row } from "react-bootstrap";

/* Custom components */
import Navigation from "./Components/Navigation";
import WallpaperCatalog from "./Components/Main/Catalog/WallpaperCatalog";
import Editor from "./Components/Main/Editor";
import LoadingScreen from "./Components/LoadingScreen";

function App() {
  const [selectedImage, setSelectedImage] = useState();

  return (
    <Routes>
      <Route
        exact
        path="/editor"
        element={
          <div>
            <Navigation selectedImage={selectedImage} />
            {selectedImage ? (
              <Editor selectedImage={selectedImage} setSelectedImage={setSelectedImage} />
            ) : (
              <Navigate to={"/catalog"} />
            )}
          </div>
        }
      ></Route>
      <Route
        exact
        path="/"
        element={
          <div>
            <Navigation selectedImage={selectedImage} />
            <LoadingScreen status={1} />
          </div>
        }
      ></Route>
      <Route
        exact
        path="/catalog"
        element={
          <div>
            <Navigation selectedImage={selectedImage} />
            <WallpaperCatalog setSelectedImage={setSelectedImage} />
          </div>
        }
      ></Route>
      <Route
        path="*"
        element={
          <div>
            <Navigation selectedImage={selectedImage} />
            <LoadingScreen status={404} />
          </div>
        }
      ></Route>
    </Routes>
  );
}

export default App;
