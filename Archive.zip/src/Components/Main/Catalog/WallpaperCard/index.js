export { default } from "./WallpaperCard";
