export { default } from "./WallpaperModal";
