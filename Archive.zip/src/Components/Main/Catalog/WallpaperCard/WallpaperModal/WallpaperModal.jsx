import React from "react";

const WallpaperModal = () => {
  return <div>WallpaperModal</div>;
};

export default WallpaperModal;
