import React, { useState } from "react";
import { Pagination, Container, Col } from "react-bootstrap";

const WallpaperPagination = ({ totalImages, imagesPerPage, currentPage, setCurrentPage }) => {
  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(totalImages / imagesPerPage); i++) {
    pageNumbers.push(
      <Pagination.Item key={i} active={currentPage === i} onClick={() => setCurrentPage(i)}>
        {i}
      </Pagination.Item>
    );
  }
  return (
    <Container fluid>
      <Col className="d-flex justify-content-center mt-3">
        <Pagination>{pageNumbers}</Pagination>
      </Col>
    </Container>
  );
};

export default WallpaperPagination;
