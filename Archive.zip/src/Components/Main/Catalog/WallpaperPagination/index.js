export { default } from "./WallpaperPagination";
