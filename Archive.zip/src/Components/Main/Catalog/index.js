export { default } from "./WallpaperCatalog";
