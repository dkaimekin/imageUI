export { default } from "./WallpaperProperties";
