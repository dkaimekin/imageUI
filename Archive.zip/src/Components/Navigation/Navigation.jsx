import React from "react";
import { Navbar, Nav, Container } from "react-bootstrap";
import { NavLink } from "react-router-dom";

const Navigation = ({ selectedImage }) => {
  console.log(selectedImage === undefined);
  return (
    <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
      <Container fluid>
        <Navbar.Brand>
          {/* Use require('./path') in image src due to webpack issue */}
          <img
            src={require("../../Images/placeholder-image.webp")}
            alt="Placeholder Logo"
            height="30"
            className="d-inline-block align-top"
          />{" "}
          Brand name
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            {selectedImage ? (
              <Nav.Item>
                <NavLink className="nav-link" to="/editor">
                  Editor
                </NavLink>
              </Nav.Item>
            ) : (
              <></>
            )}

            <Nav.Item>
              <NavLink className="nav-link" to="/catalog">
                Catalog
              </NavLink>
            </Nav.Item>
            <Nav.Item>
              <NavLink className="nav-link" to="/">
                About us
              </NavLink>
            </Nav.Item>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Navigation;
